<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Fungsi</title>
</head>
<body>
<?php
// array sort
$ar_buah = ["p"=>"Pepaya","a"=>"Apel","m"=>"Mangga","j"=>"Jambu" ]; 
echo '<ol>'; 
foreach($ar_buah as $k =>$v){ 
echo '<li>'.$k.' - ' . $v .'</li>'; 
} 
echo '</ol>'; 
sort($ar_buah); 
echo '<hr/>'; 
echo '<ol>'; 
foreach($ar_buah as $k =>$v){ 
echo '<li>'.$k.' - ' . $v .'</li>'; 
} 
echo '</ol>';
?>
<?php
// array_pop
$tims = ["Erwin", "Heru", "Ali", "Zaki"];
array_pop($tims);
foreach($tims as $person){
    echo $person. '<br/>';
}
?>
<?php
// array_push
$tims = ["Erwin", "Heru", "Ali", "Zaki"];
array_push($tims, "Wati");
foreach($tims as $person){
    echo $person. '<br/>';
}
?>
<?php
// array_shift
$tims = ["Erwin", "Heru", "Ali", "Zaki"];
array_shift($tims);
foreach($tims as $person){
    echo $person. '<br/>';
}
?>
<?php
// array_unshift
$tims = ["Erwin", "Heru", "Ali", "Zaki"];
array_unshift($tims, "Wati", "Joko");
foreach($tims as $person){
    echo $person. '<br/>';
}
?>
</body>
</html>