<?php 

// Variable User
$nama_depan = "Rakha";
$nama_belakang = 'Zahran';
$nama_paling_belakang =  "Fu'ad";
$umur = 17;
$tb = 150.9;

echo $nama_depan ." " .  $nama_belakang;
echo " <br>Nama Saya Adalah $nama_depan dan saya berumur $umur";

echo "<br /><br />";

// Variable User
echo 'Dokumen Root' . $_SERVER ['DOCUMENT_ROOT'];

// Variable Constant
echo "<br /><br />";

define('PHI', 3.14);

$r = 8;
$luas = PHI * $r * $r;

echo "Lingkaran dengan jari-jari {$r} cm memiliki luas $luas cm2";
?>