<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Nilai Mahasiswa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .card {
            margin-top: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card-title {
            color: #007bff;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Form Nilai Mahasiswa</h5>
            <form method="post" action="nilai_siswa.php">
                <div class="form-group row">
                    <label for="nama" class="col-4 col-form-label">Nama Lengkap</label>
                    <div class="col-8">
                        <input id="nama" name="nama" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nama" class="col-4 col-form-label">NIM</label>
                    <div class="col-8">
                        <input id="nim" name="nim" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="matkul" class="col-4 col-form-label">Mata Kuliah</label>
                    <div class="col-8">
                        <select id="matkul" name="matkul" class="custom-select">
                            <option value="DDP">Dasar Dasar Pemrograman</option>
                            <option value="PW1">Pemrograman Web 1</option>
                            <option value="PW2">Pemrograman Web 2</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nilai_uts" class="col-4 col-form-label">nilai UTS</label>
                    <div class="col-8">
                        <input id="nilai_uts" name="nilai_uts" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nilai_uas" class="col-4 col-form-label">nilai UAS</label>
                    <div class="col-8">
                        <input id="nilai_uas" name="nilai_uas" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nilai_tugas" class="col-4 col-form-label">Nilai Tugas/Pratikum</label>
                    <div class="col-8">
                        <input id="nilai_tugas" name="nilai_tugas" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="offset-4 col-8">
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card result">
        <div class="card-body">
            <h5 class="card-title">Lab Pemrograman Web Lanjutan</h5>
            <p><strong>Dosen:</strong> Sirojul Munir S.Si.M.Kom</p>
            <p><strong>STT-NF - Kampus B</strong></p>
        </div>
    </div>
</body>

</html>