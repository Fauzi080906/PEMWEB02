<?php

//grade nilai
function determineGrade($nilai)
{
    if ($nilai >= 0 && $nilai <= 35) {
        return 'E';
    } elseif ($nilai >= 36 && $nilai <= 55) {
        return 'D';
    } elseif ($nilai >= 56 && $nilai <= 69) {
        return 'C';
    } elseif ($nilai >= 70 && $nilai <= 84) {
        return 'B';
    } elseif ($nilai >= 85 && $nilai <= 100) {
        return 'A';
    } else {
        return 'I';
    }
}

function determinePredikat($grade)
{
    switch ($grade) {
        case 'E':
            return 'Sangat Kurang';
        case 'D':
            return 'Kurang';
        case 'C':
            return 'Cukup';
        case 'B':
            return 'Memuaskan';
        case 'A':
            return 'Sangat Memuaskan';
        case 'I':
            return 'Tidak Ada';
        default:
            return 'Grade tidak valid';
    }
}

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $matkul = $_POST['matkul'];
    $nilai_uts = $_POST['nilai_uts'];
    $nilai_uas = $_POST['nilai_uas'];
    $nilai_tugas = $_POST['nilai_tugas'];


    // status kelulusan
    $nilai_total = ($nilai_uts * 0.3) + ($nilai_uas * 0.35) + ($nilai_tugas * 0.35);
    $grade = determineGrade($nilai_total);
    $predikat = determinePredikat($grade);

    echo "<div class='card result'>
            <div class='card-body'>
                <h3 class='card-title'>Hasil Nilai Mahasiswa</h3>
                <p><strong>Nama:</strong> $nama</p>
                <p><strong>NIM:</strong> $nim</p>
                <p><strong>Mata Kuliah:</strong> $matkul</p>
                <p><strong>Nilai UTS:</strong> $nilai_uts</p>
                <p><strong>Nilai UAS:</strong> $nilai_uas</p>
                <p><strong>Nilai Tugas/Praktikum:</strong> $nilai_tugas</p>
                <p><strong>Nilai Total:</strong> $nilai_total</p>
                <p><strong>Grade:</strong> $grade</p>
                <p><strong>Predikat:</strong> $predikat</p>
                <p><strong>Status:</strong> " . ($nilai_total > 55 ? 'Lulus' : 'Tidak Lulus') . "</p>
            </div>
        </div>";
}
