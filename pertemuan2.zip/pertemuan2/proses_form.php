<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Belanja Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .card {
            margin: 20px;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .card-title {
            color: #007bff;
        }
        .result-section {
            margin-top: 20px;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Hasil Belanja Online</h5>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $customer = $_POST['customer'];
                $produk = $_POST['produk'];
                $jumlah = $_POST['jumlah'];

                // Menghitung total belanja
                $harga = [
                    "TV" => 4200000,
                    "KULKAS" => 3100000,
                    "MESIN CUCI" => 3800000
                ];
                $total = $harga[$produk] * $jumlah;

                echo "<div class='result-section'>";
                echo "<p>Nama Customer: $customer</p>";
                echo "<p>Produk Pilihan: $produk</p>";
                echo "<p>Jumlah Beli: $jumlah</p>";
                echo "<p>Total Belanja: Rp " . number_format($total, 0, ',', '.') . "</p>";
                echo "</div>";
            } else {
                echo "<p>Tidak ada data yang dikirim.</p>";
            }
            ?>
            <a href="form_belanja.php" class="btn btn-primary">Kembali ke Form</a>
        </div>
    </div>
</body>

</html>