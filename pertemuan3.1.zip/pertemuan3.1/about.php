<?php
include './top.php';
include './menu.php';
?>

<!-- Page content wrapper-->
<div id="page-content-wrapper">
    <?php
    include './navbar.php'
    ?>
    <!-- Page content-->
    <div class="container-fluid" style="text-align: justify">
        <h1 class="mt-4">Tentang Sejarah Indonesia</h1>
        <hr>
        <p>Sejarah Indonesia modern adalah sebuah narasi panjang yang penuh dengan dinamika, perjuangan, dan transformasi. 
            Sejak memproklamasikan kemerdekaannya pada 17 Agustus 1945, Indonesia telah melalui berbagai fase penting yang membentuk identitas dan karakter bangsa. 
            Setiap era—mulai dari Era Kemerdekaan, Orde Lama, Orde Baru, hingga Reformasi—membawa ciri khas, tantangan, dan pencapaian tersendiri, sekaligus meninggalkan warisan yang terus memengaruhi perkembangan negara hingga saat ini.
        </p>
        <hr>
        <h3 class="mt-4">Era Kemerdekaan (1945-1950)</h3>
        <hr>
        <p>menandai awal perjalanan Indonesia sebagai bangsa merdeka. 
            Meskipun proklamasi kemerdekaan telah dikumandangkan, Indonesia harus berjuang mati-matian mempertahankan kedaulatannya dari upaya Belanda yang ingin kembali menjajah. Melalui perjuangan fisik dan diplomasi, 
            Indonesia akhirnya berhasil mendapatkan pengakuan kedaulatan pada tahun 1949. Era ini juga menjadi fondasi bagi pembentukan identitas nasional, dengan Pancasila dan Undang-Undang Dasar 1945 sebagai pilar utama.
        </p>
        <hr>
        <h3 class="mt-4">Orde Lama (1950-1966)</h3>
        <hr>
        <p>adalah periode di mana Indonesia dipimpin oleh Presiden Soekarno. Era ini diwarnai oleh semangat nasionalisme dan upaya membangun identitas bangsa, tetapi juga ditandai oleh instabilitas politik dan ekonomi.
            Sistem demokrasi parlementer yang diterapkan pada awal 1950-an gagal menciptakan stabilitas, sehingga Soekarno beralih ke sistem Demokrasi Terpimpin pada 1959. Namun, kebijakan ini justru membawa Indonesia ke dalam krisis politik dan ekonomi, 
            yang mencapai puncaknya dengan peristiwa Gerakan 30 September (G30S) pada 1965.
        </p>
        <hr>
        <h3 class="mt-4">Orde Baru (1966-1998)</h3>
        <hr>
        <p>dimulai dengan naiknya Soeharto ke tampuk kekuasaan. Era ini dikenal sebagai masa stabilisasi politik dan pertumbuhan ekonomi, tetapi juga diwarnai oleh praktik otoritarianisme, korupsi, dan pelanggaran hak asasi manusia. 
            Soeharto membangun rezim yang sentralistik dan represif, dengan militer memainkan peran dominan dalam politik. Meskipun Indonesia mengalami kemajuan ekonomi, ketimpangan sosial dan ketergantungan pada kekuasaan pusat menjadi masalah serius. 
            Orde Baru berakhir pada 1998, ketika krisis ekonomi dan tuntutan reformasi memaksa Soeharto mengundurkan diri.
        </p>
        <hr>
        <h3 class="mt-4">Reformasi (1998-sekarang)</h3>
        <hr>
        <p>adalah era perubahan yang dimulai setelah jatuhnya Orde Baru. Reformasi membawa angin segar demokratisasi, dengan kebebasan pers, pemilihan umum yang demokratis, dan penegakan hak asasi manusia menjadi prioritas. 
            Namun, tantangan seperti korupsi, ketimpangan sosial, dan lemahnya penegakan hukum masih menjadi pekerjaan rumah yang harus diselesaikan. Reformasi mengajarkan bahwa demokratisasi adalah proses yang terus berlanjut, membutuhkan komitmen dan partisipasi seluruh elemen bangsa.
        </p>
        <hr>
        <p>Dari Era Kemerdekaan hingga Reformasi, Indonesia telah melalui perjalanan panjang yang penuh liku. Setiap era memberikan pelajaran berharga tentang pentingnya persatuan, keadilan, dan keberanian untuk berubah. 
            Memahami sejarah ini tidak hanya membantu kita menghargai perjuangan para pendahulu, tetapi juga membekali kita untuk menghadapi tantangan masa depan dengan lebih baik.
        </p>
    </div>
</div>
</div>
<?php
include './button.php';
?>