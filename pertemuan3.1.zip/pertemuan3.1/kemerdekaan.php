<?php
include './top.php';
include './menu.php';
?>

<!-- Page content wrapper-->
<div id="page-content-wrapper">
    <?php
    include './navbar.php'
    ?>
    <!-- Page content-->
    <div class="container-fluid" style="text-align: justify">
        <h1 class="mt-4">Era Kemerdekaan</h1>
        <hr>
        <p>Era kemerdekaan Indonesia dimulai pada tanggal 17 Agustus 1945, ketika Soekarno dan Mohammad Hatta memproklamasikan kemerdekaan Indonesia di Jalan Pegangsaan Timur No. 56, Jakarta. 
            Proklamasi ini menandai berakhirnya penjajahan Belanda yang berlangsung selama lebih dari 350 tahun dan pendudukan Jepang selama 3,5 tahun. Namun, perjuangan untuk mempertahankan kemerdekaan tidak berakhir dengan proklamasi tersebut. 
            Indonesia masih harus menghadapi berbagai tantangan, baik dari dalam maupun luar negeri.
        </p>
        <br>
        <p>Setelah proklamasi, Indonesia langsung membentuk pemerintahan sementara dengan Soekarno sebagai presiden dan Mohammad Hatta sebagai wakil presiden. Pada tanggal 18 Agustus 1945, 
            Panitia Persiapan Kemerdekaan Indonesia (PPKI) mengesahkan Undang-Undang Dasar 1945 sebagai konstitusi negara dan menetapkan Soekarno dan Hatta sebagai presiden dan wakil presiden pertama Indonesia. 
            Namun, Belanda tidak mengakui kemerdekaan Indonesia dan berusaha untuk kembali menguasai wilayah ini melalui agresi militer, yang dikenal sebagai Agresi Militer Belanda I (1947) dan Agresi Militer Belanda II (1948).
        </p>
        <br>
        <p>Perjuangan fisik dan diplomasi menjadi dua senjata utama Indonesia dalam mempertahankan kemerdekaan. Di medan perang, rakyat Indonesia dengan semangat juang yang tinggi melawan pasukan Belanda. 
            Pertempuran besar seperti Pertempuran Surabaya pada November 1945 menjadi simbol perlawanan rakyat Indonesia. Sementara itu, di meja diplomasi, Indonesia berhasil menarik perhatian dunia internasional. 
            Melalui Perserikatan Bangsa-Bangsa (PBB), Indonesia berhasil memenangkan dukungan internasional, yang akhirnya memaksa Belanda untuk mengakui kedaulatan Indonesia.
        </p>
        <br>
        <p>Era kemerdekaan Indonesia tidak hanya tentang perjuangan melawan penjajah, tetapi juga tentang upaya membangun identitas dan fondasi negara yang baru merdeka. Soekarno, sebagai presiden pertama, 
            memainkan peran penting dalam mempersatukan berbagai kelompok dan ideologi di Indonesia. Pancasila, yang dirumuskan sebagai dasar negara, menjadi pemersatu bangsa yang terdiri dari berbagai suku, agama, dan budaya.
        </p>
        <br>
        <p>Namun, era kemerdekaan juga diwarnai oleh berbagai konflik internal, seperti pemberontakan DI/TII, PRRI, dan Permesta, yang mencerminkan tantangan dalam menjaga persatuan dan kesatuan bangsa. Selain itu, 
            Indonesia juga menghadapi kesulitan ekonomi dan politik pada masa-masa awal kemerdekaan.
        </p>
        <br>
        <p>Meskipun begitu, era kemerdekaan Indonesia merupakan periode penting yang membentuk identitas bangsa dan meletakkan dasar bagi pembangunan negara. 
            Semangat perjuangan dan persatuan yang ditunjukkan oleh para pendiri bangsa terus menjadi inspirasi bagi generasi berikutnya dalam menjaga dan memajukan Indonesia.
        </p>
    </div>
</div>
</div>
<?php
include './button.php';
?>