<?php
include './top.php';
include './menu.php';
?>

<!-- Page content wrapper-->
<div id="page-content-wrapper">
    <?php
    include './navbar.php'
    ?>
    <!-- Page content-->
    <div class="container-fluid" style="text-align: justify">
        <h1 class="mt-4">Orde Baru</h1>
        <hr>
        <p>Orde Baru adalah periode pemerintahan di Indonesia yang berlangsung dari tahun 1966 hingga 1998, 
            di bawah kepemimpinan Presiden Soeharto. Era ini dimulai setelah jatuhnya Presiden Soekarno dan berakhir dengan lengsernya Soeharto pada tahun 1998. Orde Baru sering dianggap sebagai era stabilisasi politik dan pertumbuhan ekonomi, 
            tetapi juga ditandai oleh praktik otoritarianisme, korupsi, dan pelanggaran hak asasi manusia.
        </p>
        <hr>
        <h3 class="mt-4">Latar Belakang Dan Awal Orde Baru</h3>
        <hr>
        <p>Orde Baru lahir dari kekacauan politik dan ekonomi pada akhir era Orde Lama. Setelah peristiwa Gerakan 30 September (G30S) pada tahun 1965, yang diduga melibatkan Partai Komunis Indonesia (PKI), situasi politik Indonesia menjadi sangat tegang. 
            Soekarno, yang dianggap melindungi PKI, kehilangan dukungan dari militer dan kelompok anti-komunis. Pada 11 Maret 1966, Soekarno menandatangani Surat Perintah 11 Maret (Supersemar), yang memberikan wewenang kepada Mayor Jenderal Soeharto untuk mengambil langkah-langkah guna memulihkan keamanan dan stabilitas.
        </p>
        <br>
        <p>Dengan kekuasaan yang semakin besar, Soeharto secara bertahap mengambil alih pemerintahan. Pada tahun 1967, Soeharto diangkat sebagai Pejabat Presiden, dan pada tahun 1968, ia secara resmi menjadi Presiden Republik Indonesia. 
            Periode ini menandai dimulainya Orde Baru, dengan fokus pada stabilisasi politik, pembangunan ekonomi, dan penekanan terhadap ideologi komunis.
        </p>
        <hr>
        <h3 class="mt-4">Stabilisasi Politik dan Sentralisasi Kekuasaan</h3>
        <hr>
        <p>Salah satu ciri utama Orde Baru adalah sentralisasi kekuasaan di tangan Soeharto dan militer. Soeharto membentuk rezim yang otoriter, di mana partai politik dan lembaga demokrasi dikendalikan secara ketat. Pada tahun 1973, 
            pemerintah menyederhanakan sistem kepartaian dengan menggabungkan partai-partai Islam menjadi Partai Persatuan Pembangunan (PPP) dan partai-partai non-Islam menjadi Partai Demokrasi Indonesia (PDI). Sementara itu, Golongan Karya (Golkar), 
            yang didukung oleh pemerintah dan militer, menjadi partai dominan yang selalu memenangkan pemilu.
        </p>
        <br>
        <p>Selain itu, militer memainkan peran penting dalam politik melalui konsep "Dwi Fungsi ABRI", yang memberikan peran ganda kepada militer sebagai penjaga keamanan dan pelaku politik. 
            Hal ini membuat militer memiliki pengaruh besar dalam pemerintahan dan birokrasi.
        </p>
        <hr>
        <h3 class="mt-4">Pembangunan Ekonomi</h3>
        <hr>
        <p>Salah satu keberhasilan Orde Baru adalah pertumbuhan ekonomi yang pesat. Dengan bantuan dari negara-negara Barat dan lembaga keuangan internasional seperti Bank Dunia dan IMF, 
            Indonesia melaksanakan program pembangunan yang berfokus pada industrialisasi, infrastruktur, dan peningkatan kesejahteraan rakyat. Pada tahun 1980-an, Indonesia mengalami pertumbuhan ekonomi yang signifikan, dengan peningkatan pendapatan per kapita dan penurunan tingkat kemiskinan.
        </p>
        <br>
        <p>Namun, pertumbuhan ekonomi ini tidak merata. Kesenjangan antara kaya dan miskin semakin melebar, dan pembangunan lebih terkonsentrasi di Jawa dan beberapa wilayah tertentu. Selain itu, praktik korupsi, kolusi, 
            dan nepotisme (KKN) yang merajalela di kalangan pejabat pemerintah dan keluarga Soeharto menjadi masalah serius yang menggerogoti perekonomian negara.
        </p>
        <hr>
        <h3 class="mt-4">Penekanan terhadap Oposisi dan Pelanggaran HAM</h3>
        <hr>
        <p>Rezim Orde Baru dikenal represif terhadap oposisi dan kritik. Pemerintah menggunakan aparat keamanan untuk membungkam suara-suara yang menentang, termasuk aktivis mahasiswa, intelektual, dan kelompok masyarakat sipil. Pelanggaran hak asasi manusia terjadi secara sistematis, 
            seperti dalam kasus pembantaian terhadap anggota PKI setelah G30S, penindasan terhadap gerakan separatis di Aceh dan Papua, serta penembakan mahasiswa dalam peristiwa Trisakti pada tahun 1998.
        </p>
        <hr>
        <h3 class="mt-4">Akhir Orde Baru</h3>
        <hr>
        <p>Pada akhir 1990-an, krisis ekonomi Asia melanda Indonesia, menyebabkan nilai rupiah merosot dan inflasi melambung tinggi. Krisis ini memicu ketidakpuasan masyarakat terhadap pemerintah, yang dianggap gagal mengatasi masalah ekonomi dan korupsi. 
            Demonstrasi besar-besaran yang dipimpin oleh mahasiswa dan kelompok masyarakat sipil menuntut reformasi politik dan pengunduran diri Soeharto.
        </p>
        <br>
        <p>Pada 21 Mei 1998, setelah tekanan yang semakin besar, Soeharto mengumumkan pengunduran dirinya dari jabatan presiden. Peristiwa ini menandai berakhirnya Orde Baru dan dimulainya era Reformasi.</p>
    </div>
</div>
</div>
<?php
include './button.php';
?>