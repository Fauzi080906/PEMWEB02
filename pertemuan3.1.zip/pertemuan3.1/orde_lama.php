<?php
include './top.php';
include './menu.php';
?>

<!-- Page content wrapper-->
<div id="page-content-wrapper">
    <?php
    include './navbar.php'
    ?>
    <!-- Page content-->
    <div class="container-fluid" style="text-align: justify">
        <h1 class="mt-4">Orde Lama</h1>
        <hr>
        <p>Orde Lama merujuk pada periode pemerintahan di Indonesia yang berlangsung dari tahun 1945 hingga 1966, 
            di bawah kepemimpinan Presiden Soekarno. Periode ini dimulai setelah proklamasi kemerdekaan Indonesia pada 17 Agustus 1945 dan berakhir dengan turunnya Soekarno dari jabatan presiden pada tahun 1966. 
            Orde Lama merupakan era yang penuh dengan dinamika politik, ekonomi, dan sosial, serta menjadi fondasi bagi pembentukan identitas bangsa Indonesia.
        </p>
        <h3 class="mt-4">Awal Kemerdekaan dan Perjuangan Mempertahankan Kedaulatan (1945-1950)</h3>
        <hr>
        <p>Setelah proklamasi kemerdekaan, Indonesia langsung dihadapkan pada tantangan besar, yaitu mempertahankan kemerdekaan dari upaya Belanda yang ingin kembali menguasai wilayah ini. Periode ini dikenal sebagai masa Revolusi Nasional Indonesia. 
            Meskipun Belanda melancarkan agresi militer pada tahun 1947 dan 1948, rakyat Indonesia dengan gigih mempertahankan kemerdekaan melalui perjuangan fisik dan diplomasi. Pada akhirnya, melalui Perjanjian Konferensi Meja Bundar (KMB) pada tahun 1949, 
            Belanda mengakui kedaulatan Indonesia secara resmi pada 27 Desember 1949.
        </p>
        <hr>
        <h3 class="mt-4">Demokrasi Parlementer (1950-1959)</h3>
        <hr>
        <p>Setelah pengakuan kedaulatan, Indonesia memasuki era Demokrasi Parlementer. Pada masa ini, sistem pemerintahan Indonesia menganut model parlementer, di mana perdana menteri memegang kekuasaan eksekutif, sementara presiden berperan sebagai kepala negara. 
            Namun, periode ini diwarnai oleh instabilitas politik akibat seringnya pergantian kabinet. Dalam kurun waktu 9 tahun, terdapat lebih dari 7 kabinet yang berbeda, yang mencerminkan fragmentasi politik dan persaingan antarpartai.
        </p>
        <br>
        <p>Beberapa partai besar seperti Partai Nasional Indonesia (PNI), Masyumi, dan Partai Komunis Indonesia (PKI) saling bersaing untuk mendominasi pemerintahan. Selain itu, munculnya pemberontakan daerah seperti PRRI dan Permesta menunjukkan ketidakpuasan terhadap pemerintah pusat. 
            Kondisi ini membuat Soekarno semakin kritis terhadap sistem demokrasi parlementer, yang dianggapnya tidak cocok untuk Indonesia.
        </p>
        <hr>
        <h3 class="mt-4">Demokrasi Terpimpin (1959-1966)</h3>
        <hr>
        <P>Pada tahun 1959, Soekarno mengeluarkan Dekrit Presiden 5 Juli 1959, yang membubarkan Konstituante dan mengembalikan UUD 1945 sebagai konstitusi negara. Dekrit ini menandai dimulainya era Demokrasi Terpimpin, di mana kekuasaan terpusat pada presiden. 
            Soekarno menerapkan konsep "NASAKOM" (Nasionalis, Agama, Komunis) sebagai upaya untuk mempersatukan tiga kekuatan politik utama di Indonesia.
        </P>
        <br>
        <p>Namun, Demokrasi Terpimpin justru membawa Indonesia ke dalam situasi politik yang semakin otoriter. Soekarno mengendalikan hampir seluruh aspek pemerintahan, sementara partai-partai politik dan lembaga demokrasi lainnya semakin kehilangan pengaruh. 
            Di sisi ekonomi, kebijakan Soekarno yang lebih fokus pada proyek-proyek mercusuar dan simbolis, seperti pembangunan Monumen Nasional (Monas) dan Gelora Bung Karno, mengakibatkan defisit anggaran dan hiperinflasi.
        </p>
        <hr>
        <h3 class="mt-4">Konfrontasi dengan Malaysia dan Dekatnya Hubungan dengan Blok Timur</h3>
        <hr>
        <p>Pada masa Orde Lama, Indonesia juga terlibat dalam konfrontasi dengan Malaysia, yang dianggap sebagai proyek neo-kolonialisme Inggris. Soekarno menolak pembentukan Federasi Malaysia dan melancarkan kampanye "Ganyang Malaysia". 
            Selain itu, Indonesia semakin dekat dengan Blok Timur, terutama Uni Soviet dan Tiongkok, yang membuat hubungan dengan negara-negara Barat, termasuk Amerika Serikat, menjadi tegang.
        </p>
        <hr>
        <h3 class="mt-4">Akhir Orde Lama</h3>
        <hr>
        <p>Situasi politik dan ekonomi yang semakin buruk mencapai puncaknya pada tahun 1965, ketika terjadi peristiwa Gerakan 30 September (G30S). Peristiwa ini, yang diduga melibatkan PKI, memicu reaksi keras dari militer dan kelompok anti-komunis. 
            Soekarno, yang dianggap melindungi PKI, kehilangan dukungan politik. Pada tahun 1966, Soekarno menyerahkan kekuasaan kepada Jenderal Soeharto melalui Surat Perintah 11 Maret (Supersemar), yang menandai berakhirnya Orde Lama dan dimulainya Orde Baru.
        </p>
    </div>
</div>
</div>
<?php
include './button.php';
?>