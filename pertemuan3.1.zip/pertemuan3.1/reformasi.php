<?php
include './top.php';
include './menu.php';
?>

<!-- Page content wrapper-->
<div id="page-content-wrapper">
    <?php
    include './navbar.php'
    ?>
    <!-- Page content-->
    <div class="container-fluid" style="text-align: justify">
        <h1 class="mt-4">Reformasi</h1>
        <hr>
        <p>Reformasi Indonesia adalah era perubahan politik, ekonomi, dan sosial yang dimulai pada tahun 1998, setelah jatuhnya rezim Orde Baru di bawah Presiden Soeharto. Era ini ditandai oleh tuntutan demokratisasi, penegakan hak asasi manusia (HAM), dan pemberantasan korupsi, kolusi, dan nepotisme (KKN). 
            Reformasi menjadi titik balik penting dalam sejarah Indonesia, mengakhiri 32 tahun pemerintahan otoriter dan membuka jalan bagi sistem politik yang lebih terbuka dan demokratis.
        </p>
        <h3 class="mt-4">Latar Belakang Reformasi</h3>
        <hr>
        <p>Reformasi dipicu oleh krisis multidimensi yang melanda Indonesia pada akhir 1990-an. Krisis ekonomi Asia 1997 menyebabkan nilai rupiah merosot tajam, inflasi melambung, dan pengangguran meningkat. Kondisi ini diperparah oleh praktik korupsi, kolusi, dan nepotisme (KKN) yang merajalela di kalangan pejabat pemerintah dan keluarga Soeharto. 
            Ketidakpuasan masyarakat terhadap pemerintah Orde Baru semakin memuncak, terutama di kalangan mahasiswa, intelektual, dan kelompok masyarakat sipil.
        </p>
        <br>
        <p>Demonstrasi besar-besaran terjadi di berbagai kota, menuntut reformasi politik, pengunduran diri Soeharto, dan penghapusan KKN. Puncaknya terjadi pada Mei 1998, ketika empat mahasiswa Universitas Trisakti tewas ditembak dalam demonstrasi. Peristiwa ini memicu gelombang protes dan kerusuhan yang lebih besar, 
            yang akhirnya memaksa Soeharto mengundurkan diri pada 21 Mei 1998.
        </p>
        <h3 class="mt-4">Transisi Menuju Reformasi</h3>
        <hr>
        <p>Setelah pengunduran diri Soeharto, Wakil Presiden B.J. Habibie mengambil alih jabatan presiden. Habibie memulai proses reformasi dengan langkah-langkah signifikan, seperti membebaskan tahanan politik, mencabut pembatasan kebebasan pers, dan mengizinkan pendirian partai-partai politik baru. Pada tahun 1999, 
            Indonesia menyelenggarakan pemilihan umum multipartai yang demokratis untuk pertama kalinya sejak 1955. Pemilu ini dimenangkan oleh Partai Demokrasi Indonesia Perjuangan (PDI-P) yang dipimpin oleh Megawati Soekarnoputri.
        </p>
        <br>
        <p>Selain itu, Habibie juga memulai proses desentralisasi dengan mengesahkan Undang-Undang Otonomi Daerah pada tahun 1999, yang memberikan kewenangan lebih besar kepada pemerintah daerah. Langkah ini bertujuan untuk mengurangi ketimpangan pembangunan antara pusat dan daerah serta meredam 
            tuntutan separatisme di beberapa wilayah seperti Aceh dan Papua.
        </p>
        <h3 class="mt-4">Perubahan Konstitusi dan Penegakan HAM</h3>
        <hr>
        <p>Salah satu pencapaian penting era Reformasi adalah amandemen Undang-Undang Dasar 1945. Antara tahun 1999 dan 2002, dilakukan empat kali amandemen yang bertujuan untuk membatasi kekuasaan presiden, memperkuat sistem checks and balances, dan memperluas hak-hak warga negara. 
            Amandemen ini juga membentuk lembaga-lembaga baru seperti Mahkamah Konstitusi dan Komisi Yudisial untuk memastikan independensi peradilan.
        </p>
        <br>
        <p>Era Reformasi juga menekankan penegakan hak asasi manusia. Komisi Nasional Hak Asasi Manusia (Komnas HAM) diberi mandat yang lebih kuat untuk menyelidiki pelanggaran HAM masa lalu, seperti peristiwa 1965, Tragedi Trisakti, Semanggi I dan II, 
            serta kasus-kasus kekerasan di Aceh dan Papua. Meskipun banyak kasus belum sepenuhnya terselesaikan, upaya ini menunjukkan komitmen pemerintah untuk memperbaiki masa lalu.
        </p>
        <hr>
        <h3 class="mt-4">Tantangan Dan Masalah Reformasi</h3>
        <hr>
        <p>Meskipun Reformasi membawa banyak perubahan positif, era ini juga dihadapkan pada berbagai tantangan. Korupsi tetap menjadi masalah serius, meskipun lembaga seperti Komisi Pemberantasan Korupsi (KPK) didirikan pada tahun 2002 untuk memerangi praktik korupsi. 
            Selain itu, konflik sosial dan kekerasan antar kelompok masih terjadi, seperti kerusuhan etnis di Kalimantan dan konflik agama di Poso.
        </p>
        <br>
        <p>Di bidang ekonomi, Indonesia berhasil pulih dari krisis 1998, tetapi pertumbuhan ekonomi tidak selalu inklusif. Kesenjangan sosial dan ekonomi antara kelompok kaya dan miskin masih menjadi masalah yang perlu diatasi. Selain itu, reformasi di sektor hukum dan birokrasi berjalan lambat, 
            menghambat upaya untuk menciptakan tata pemerintahan yang lebih baik.
        </p>
        <hr>
        <h3 class="mt-4">Warisan Reformasi</h3>
        <hr>
        <p>Reformasi telah mengubah wajah Indonesia menjadi negara yang lebih demokratis dan terbuka. Kebebasan pers, kebebasan berpendapat, dan kebebasan berserikat menjadi hak yang dijamin oleh konstitusi. 
            Pemilihan umum yang demokratis dan kompetitif telah menjadi rutinitas, dengan presiden dan wakil presiden dipilih langsung oleh rakyat sejak 2004.
        </p>
        <br>
        <p>Namun, warisan Reformasi juga mengingatkan kita bahwa demokratisasi adalah proses yang terus berlanjut. Tantangan seperti korupsi, ketimpangan sosial, dan penegakan hukum masih perlu diatasi untuk mewujudkan cita-cita Reformasi, 
            yaitu menciptakan Indonesia yang adil, makmur, dan demokratis. Era Reformasi menjadi bukti bahwa perubahan adalah mungkin, tetapi membutuhkan komitmen dan kerja keras dari seluruh elemen bangsa.</p>
    </div>
</div>
</div>
<?php
include './button.php';
?>