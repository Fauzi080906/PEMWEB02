<?php
$menus = [
    "Home" => "index.php",
    "About" => "about.php",
    "Kemerdekaan" => "kemerdekaan.php",
]
?>

<!-- Sidebar-->
<div class="border-end bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading border-bottom bg-light">Sejarah Indonesia</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="./index.php">Home</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="./about.php">Tentang</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="./kemerdekaan.php">Era Kemerdekaan</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="./orde_lama.php">Orde Lama</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="./orde_baru.php">Orde Baru</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="./reformasi.php">Reformasi</a>
                </div>
            </div>